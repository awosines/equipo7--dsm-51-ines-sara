package com.example.flutter_authentication_with_laravel_sanctum

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
