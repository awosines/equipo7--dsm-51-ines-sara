package com.example.dsm51_07

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
